<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dark Store - المتجر الإلكتروني</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="icon" href="assets/images/logo.jpg">
    <style>
        /* كل أنماط CSS الأصلية هنا بدون أي تغيير */
        :root {
            --red: #e11d48;
            --red-dark: #a31536;
            --black: #18181b;
            --black-light: #23232a;
            --white: #fff;
            --gray: #a1a1aa;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; scroll-behavior: smooth; }
        body {
            font-family: 'Cairo', sans-serif;
            background: var(--black);
            color: var(--white);
            min-height: 100vh;
        }
        a { text-decoration: none; color: inherit; }
        .container { max-width: 1100px; margin: 0 auto; padding: 0 1rem; }
        .section { padding: 4rem 0; }
        .section-title { text-align: center; font-size: 2rem; font-weight: 900; color: var(--white); margin-bottom: 1rem; }
        .section-title span { color: var(--red); }
        .section-subtitle { text-align: center; color: var(--gray); max-width: 600px; margin: 0 auto 3rem auto; }

        /* Header (Desktop) */
        .main-header {
            background: var(--black-light);
            border-bottom: 2px solid var(--red);
            padding: 0.5rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .header-container {
            min-height: 30px;
            display: flex; align-items: center; justify-content: space-between;
        }
        .logo {
            font-size: 2.2rem;
            font-weight: 900;
            color: var(--red);
            padding-right: 6rem;
        }
        .logo span { color: var(--white); }
        .nav-links { display: flex; gap: 1.5rem; }
        .nav-links a {
            color: var(--white);
            font-weight: 700;
            font-size: 1.1rem;
            padding: 0.3rem 0.7rem;
            border-radius: 1rem;
            transition: background 0.2s, color 0.2s;
            position: relative;
        }
        .nav-links a.active,
        .nav-links a:focus,
        .nav-links a:hover {
            background: var(--red);
            color: var(--white);
        }
        .cta-btn {
            background: var(--red);
            color: var(--white);
            padding: 0.5rem 2rem;
            border-radius: 2rem;
            font-weight: 700;
            font-size: 1.1rem;
            border: none;
            transition: background 0.2s;
            display: inline-block;
            margin-left: 3rem;
        }
        .cta-btn:hover { background: var(--red-dark); }

        /* Hero Section */
        .hero {
            background: linear-gradient(120deg, #18181b 60%, #e11d48 120%);
            padding: 4rem 0; text-align: center;
        }
        .hero h1 { font-size: 2.5rem; font-weight: 900; color: var(--white); margin-bottom: 1rem; }
        .hero h1 span { color: var(--red); }
        .hero p { color: var(--gray); font-size: 1.1rem; margin-bottom: 1.5rem; max-width: 500px; margin: 0 auto 1.5rem auto; }
        .cta-btn-main { margin-top: 1.5rem; }

        /* أنماط جديدة للبحث والتصفية */
        .search-filter-section {
            background: var(--black-light);
            padding: 1.5rem;
            border-radius: 1rem;
            margin: 2rem auto;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .search-container {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .search-input {
            flex: 1;
            padding: 0.8rem 1.2rem;
            border-radius: 2rem;
            border: none;
            background: var(--black);
            color: var(--white);
            font-family: 'Cairo', sans-serif;
            font-size: 1rem;
        }
        .search-button {
            background: var(--red);
            color: var(--white);
            border: none;
            padding: 0 1.5rem;
            border-radius: 2rem;
            cursor: pointer;
            font-family: 'Cairo', sans-serif;
            font-weight: 700;
            transition: background 0.2s;
        }
        .search-button:hover {
            background: var(--red-dark);
        }
        .categories-filter {
            display: flex;
            flex-wrap: wrap;
            gap: 0.8rem;
            justify-content: center;
        }
        .category-btn {
            background: var(--black);
            color: var(--white);
            border: 1px solid var(--gray);
            padding: 0.5rem 1.2rem;
            border-radius: 2rem;
            cursor: pointer;
            transition: all 0.2s;
            font-family: 'Cairo', sans-serif;
        }
        .category-btn:hover, .category-btn.active {
            background: var(--red);
            color: var(--white);
            border-color: var(--red);
        }

        /* أنماط جديدة لعرض المنتجات */
        .products-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }
        .product-card {
            background: var(--black-light);
            border-radius: 1rem;
            overflow: hidden;
            transition: transform 0.3s, box-shadow 0.3s;
            position: relative;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(225, 29, 72, 0.1);
        }
        .product-image-container {
            width: 100%;
            height: 200px;
            background: var(--black);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            border-radius: 1rem 1rem 0 0;
        }
        .product-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 0.7rem;
            box-shadow: 0 2px 12px rgba(225,29,72,0.08);
            transition: transform 0.3s;
        }
        .product-card:hover .product-image {
            transform: scale(1.07) rotate(-1deg);
            box-shadow: 0 8px 24px rgba(225,29,72,0.18);
        }
        .product-info {
            padding: 1.2rem;
        }
        .product-category {
            display: inline-block;
            background: var(--red);
            color: var(--white);
            padding: 0.3rem 0.8rem;
            border-radius: 1rem;
            font-size: 0.8rem;
            margin-bottom: 0.5rem;
        }
        .product-title {
            font-size: 1.2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--white);
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .product-description {
            color: var(--gray);
            font-size: 0.9rem;
            margin-bottom: 1rem;
            line-height: 1.5;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .product-footer {
            display: flex;
            flex-direction: column;
            align-items: stretch;
            margin-top: 1rem;
            gap: 0.3rem;
        }
        .product-price {
            font-weight: 900;
            color: #e11d48;
            font-size: 1.08rem;
            text-align: center;
            margin-bottom: 0.2rem;
            letter-spacing: 0.2px;
        }
        .product-actions {
            display: flex;
            flex-direction: row;
            gap: 0.5rem;
            width: 100%;
            justify-content: center;
            align-items: center;
            margin-top: 0;
        }
        .product-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            border: none;
            box-shadow: 0 1px 4px #e11d4815;
            transition: background 0.18s, color 0.18s, box-shadow 0.18s, transform 0.15s;
            position: relative;
            cursor: pointer;
            padding: 0;
        }
        .product-btn.add-to-cart-btn {
            background: linear-gradient(135deg, #e11d48 80%, #a31536 100%);
            color: #fff;
            border-radius: 0.7rem;
            font-size: 1.08rem;
            font-weight: 800;
            padding: 0.7rem 1.2rem;
            min-width: 110px;
            max-width: 100%;
            height: 38px;
            letter-spacing: 0.2px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .product-btn.add-to-cart-btn:hover {
            background: #a31536;
            transform: scale(1.05);
        }
        .product-btn.details {
            width: 38px;
            height: 38px;
            min-width: 38px;
            min-height: 38px;
            max-width: 38px;
            max-height: 38px;
            border-radius: 50%;
            background: #fff;
            color: #e11d48;
            border: 1.5px solid #e11d48;
            font-size: 1.15rem;
            justify-content: center;
            align-items: center;
            padding: 0;
        }
        .product-btn.details:hover {
            background: #e11d48;
            color: #fff;
            transform: scale(1.08);
        }
        .product-btn i {
            margin: 0;
            font-size: 1.15em;
        }
        .product-btn.add-to-cart-btn i {
            margin-left: 0.4rem;
            font-size: 1.1em;
        }
        .product-btn[title]:hover:after {
            content: attr(title);
            position: absolute;
            bottom: 120%;
            left: 50%;
            transform: translateX(-50%);
            background: #23232a;
            color: #fff;
            padding: 4px 12px;
            border-radius: 0.5rem;
            font-size: 0.85rem;
            white-space: nowrap;
            box-shadow: 0 2px 8px #0002;
            opacity: 0.95;
            pointer-events: none;
            z-index: 10;
        }
        @media (max-width: 768px) {
            .product-footer {
                gap: 0.18rem;
            }
            .product-btn.details {
                width: 32px;
                height: 32px;
                min-width: 32px;
                min-height: 32px;
                max-width: 32px;
                max-height: 32px;
                font-size: 0.98rem;
            }
            .product-btn.add-to-cart-btn {
                min-width: 80px;
                height: 32px;
                font-size: 0.95rem;
                padding: 0.5rem 0.7rem;
            }
            .product-actions {
                gap: 0.22rem;
            }
        }

        /* Footer */
        footer { background: #000; color: var(--gray); padding: 0.6rem 1rem; margin-top: 3rem; text-align: center; }

        /* --- Mobile Styles --- */
        .mobile-app {
            display: none;
            background: #18181b;
            min-height: 100vh;
            font-family: 'Cairo', sans-serif;
        }
        @media (max-width: 768px) {
            .desktop-section { display: none !important; }
            .mobile-app { display: block !important; padding-bottom: 80px; }
            .main-header { display: none; }
             .mobile-hero {
                background: linear-gradient(120deg, #18181b 60%, #e11d48 120%);
                padding: 2.5rem 1rem 2.5rem 1rem;
                text-align: center;
                border-radius: 0 0 1.5rem 1.5rem;
            }
            .mobile-hero h1 {
                font-size: 1.6rem !important;
                margin-bottom: 0.7rem !important;
                font-weight: 900;
                color: #fff;
                line-height: 1.3;
                letter-spacing: 1px;
            }
            .mobile-hero h1 span { color: #e11d48; }
            .mobile-hero p {
                color: #fff;
                font-size: 1rem !important;
                margin-bottom: 0.8rem !important;
                line-height: 1.7;
            }
            .mobile-hero .cta-btn-main {
                background: #e11d48;
                color: #fff;
                padding: 0.5rem 1.5rem;
                border-radius: 1.5rem;
                font-weight: 700;
                font-size: 1rem;
                display: inline-block;
                margin-top: 1rem;
            }
            .mobile-search-filter {
                padding: 0.3rem 0.1rem 0.1rem 0.1rem;
                background: transparent;
                margin-bottom: 0.3rem;
                border-radius: 0.8rem;
            }
            .mobile-search-container {
                display: flex;
                align-items: center;
                background: #fff;
                border-radius: 2rem;
                box-shadow: 0 1px 6px rgba(0,0,0,0.08);
                padding: 0.1rem 0.2rem;
                gap: 0;
                border: 1px solid #e11d48;
                margin-bottom: 0.3rem;
            }
            .mobile-search-input {
                flex: 1;
                padding: 0.5rem 0.7rem;
                border-radius: 2rem;
                border: none;
                background: transparent;
                color: #18181b;
                font-family: 'Cairo', sans-serif;
                font-size: 1rem;
                outline: none;
                min-width: 0;
            }
            .mobile-search-input::placeholder {
                color: #a1a1aa;
                font-size: 0.95rem;
            }
            .mobile-search-button {
                background: #e11d48;
                color: #fff;
                border: none;
                padding: 0.4rem 1rem;
                border-radius: 2rem;
                cursor: pointer;
                font-size: 1.1rem;
                box-shadow: 0 1px 4px rgba(225,29,72,0.10);
                transition: background 0.2s;
                display: flex;
                align-items: center;
                margin-left: 0.2rem;
                height: 2.2rem;
            }
            .mobile-search-button:active, .mobile-search-button:focus {
                background: #a31536;
            }
            .mobile-search-button i {
                margin: 0;
            }
            .mobile-categories-scroll {
                display: flex;
                overflow-x: auto;
                gap: 0.5rem;
                padding-bottom: 0.5rem;
            }
            .mobile-categories-scroll::-webkit-scrollbar {
                height: 4px;
            }
            .mobile-categories-scroll::-webkit-scrollbar-thumb {
                background: #e11d48;
                border-radius: 2px;
            }
            .mobile-category-btn {
                background: #18181b;
                color: #fff;
                border: 1px solid #3f3f46;
                padding: 0.4rem 1rem;
                border-radius: 1.5rem;
                white-space: nowrap;
                font-size: 0.85rem;
            }
            .mobile-category-btn.active {
                background: #e11d48;
                border-color: #e11d48;
            }
            .mobile-products {
                padding: 1rem;
            }
               .bottom-nav {
                position: fixed;
                bottom: 0; left: 0; right: 0;
                background: #23232a;
                border-top: 2px solid #e11d48;
                display: flex;
                justify-content: space-around;
                align-items: stretch;
                padding: 0.5rem 0;
                z-index: 1000;
            }
            .bottom-nav a {
                color: #fff;
                display: flex;
                flex-direction: column;
                align-items: center;
                font-weight: 700;
                font-size: 0.85rem;
                padding: 0.2rem 0.5rem;
                flex-grow: 1;
                transition: color 0.2s;
            }
            .bottom-nav a.active, .bottom-nav a:hover { color: #e11d48; }
            .bottom-nav i { font-size: 1.5rem; margin-bottom: 4px; }
            /* --- تحسين كارد المنتجات للموبايل: أصغر وتصميم مختلف --- */
            @media (max-width: 768px) {
                .products-container {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 1rem;
                    margin-top: 1.2rem;
                    padding: 0 0.3rem;
                }
                .product-card {
                    background: #23232a;
                    border-radius: 0.8rem;
                    overflow: hidden;
                    box-shadow: 0 2px 10px rgba(225,29,72,0.10);
                    transition: transform 0.18s, box-shadow 0.18s;
                    position: relative;
                    display: flex;
                    flex-direction: column;
                    min-height: 220px;
                    max-width: 100%;
                }
                .product-card:hover {
                    transform: scale(1.03);
                    box-shadow: 0 6px 18px rgba(225,29,72,0.16);
                }
                .product-image-container {
                    width: 100%;
                    height: 110px;
                    background: #18181b;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    overflow: hidden;
                    border-radius: 0.8rem 0.8rem 0 0;
                }
                .product-image {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                    border-radius: 0.6rem;
                    box-shadow: none;
                    transition: transform 0.2s;
                }
                .product-card:hover .product-image {
                    transform: scale(1.05);
                }
                .product-info {
                    padding: 0.7rem 0.6rem 0.5rem 0.6rem;
                    display: flex;
                    flex-direction: column;
                    flex: 1;
                }
                .product-category {
                    display: inline-block;
                    background: #e11d48;
                    color: #fff;
                    padding: 0.13rem 0.5rem;
                    border-radius: 0.7rem;
                    font-size: 0.7rem;
                    margin-bottom: 0.2rem;
                }
                .product-title {
                    font-size: 0.98rem;
                    font-weight: 800;
                    margin-bottom: 0.15rem;
                    color: #fff;
                    display: -webkit-box;
                    -webkit-line-clamp: 1;
                    -webkit-box-orient: vertical;
                    overflow: hidden;
                }
                .product-description {
                    color: #a1a1a1;
                    font-size: 0.78rem;
                    margin-bottom: 0.4rem;
                    line-height: 1.4;
                    display: -webkit-box;
                    -webkit-line-clamp: 1;
                    -webkit-box-orient: vertical;
                    overflow: hidden;
                }
                .product-footer {
                    display: flex;
                    flex-direction: column;
                    align-items: stretch;
                    margin-top: auto;
                }
                .product-price {
                    font-weight: 900;
                    color: #e11d48;
                    font-size: 1.01rem;
                    letter-spacing: 0.2px;
                }
                .product-actions {
                    display: flex;
                    flex-direction: column;
                    gap: 0.5rem;
                    width: 100%;
                    margin-top: 0.7rem;
                }
                .product-btn {
                    width: 100%;
                    margin: 0 auto;
                    border-radius: 0.7rem;
                    font-size: 1.08rem;
                    padding: 0.7rem 0;
                    font-weight: 800;
                    box-shadow: 0 2px 8px #e11d4820;
                    letter-spacing: 0.2px;
                }
            
                .product-btn.add-to-cart-btn {
                    background: linear-gradient(90deg, #e11d48 80%, #a31536 100%);
                    color: #fff;
                    border: none;
                    margin-bottom: 0.2rem;
                }
                .product-btn.add-to-cart-btn:hover {
                    background: #a31536;
                }
                .product-btn.details {
                    background: #fff;
                    color: #e11d48;
                    border: 2px solid #e11d48;
                    margin-bottom: 0;
                }
                .product-btn.details:hover {
                    background: #e11d48;
                    color: #fff;
                }
                .product-btn i {
                    margin-left: 0.2rem;
                }
                .product-btn:active, .product-btn:focus {
                    background: #a31536;
                }
            
            }
        }
        @media (min-width: 769px) {
            .bottom-nav { display: none !important; }
        }

        /* زر السلة العائم (Floating Cart Button) */
        #floating-cart-btn {
            position: fixed;
            left: 18px;
            bottom: 92px;
            z-index: 900;
            background: #e11d48;
            color: #fff;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            box-shadow: 0 4px 24px #0004;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            transition: background 0.18s;
        }
        #floating-cart-btn:hover {
            background: #a31536;
        }
        #cart-count {
            position: absolute;
            top: 5px;
            left: 5px;
            background: #fff;
            color: #e11d48;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.95rem;
            font-weight: 900;
            box-shadow: 0 2px 8px #0002;
        }
        @media (max-width: 600px) {
            #floating-cart-btn {
                width:54px;
                height:54px;
                font-size:1.4rem;
                bottom: 89px !important; /* استخدم !important وأقلل القيمة لتجربة فعالة */
                left:10px !important;
                top:auto !important;
                cursor: pointer;
            }
            #cart-count {
                width:20px;
                height:20px;
                font-size:0.95rem;
                top:4px;
                left:4px;
            }
            .bottom-nav {
                height: auto !important;
                min-height: 0 !important;
            }
        }
        #floating-cart-btn { cursor: pointer; } /* المؤشر كف في كل الشاشات */

        /* أزرار التفاصيل والسلة بشكل جديد: دائري، أيقونة فقط، مع Tooltip، ألوان متباينة، وحجم صغير وناعم */
        .product-footer {
            display: flex;
            flex-direction: column;
            align-items: stretch;
            margin-top: 1rem;
            gap: 0.3rem;
        }
        .product-price {
            font-weight: 900;
            color: #e11d48;
            font-size: 1.08rem;
            text-align: center;
            margin-bottom: 0.2rem;
            letter-spacing: 0.2px;
        }
        .product-actions {
            display: flex;
            flex-direction: row;
            gap: 0.5rem;
            width: 100%;
            justify-content: center;
            align-items: center;
            margin-top: 0;
        }
        .product-btn {
            /* زر التفاصيل فقط دائري */
            width: 38px;
            height: 38px;
            min-width: 38px;
            min-height: 38px;
            max-width: 38px;
            max-height: 38px;
            border-radius: 50%;
            font-size: 1.15rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border: none;
            box-shadow: 0 1px 4px #e11d4815;
            transition: background 0.18s, color 0.18s, box-shadow 0.18s, transform 0.15s;
            position: relative;
            cursor: pointer;
            padding: 0;
        }
        .add-to-cart-btn {
            /* زر السلة مستطيل أنيق */
            border-radius: 0.7rem;
            width: auto;
            min-width: 90px;
            max-width: 160px;
            height: 38px;
            padding: 0 1.1rem;
            font-size: 1.05rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            background: linear-gradient(135deg, #e11d48 80%, #a31536 100%);
            color: #fff;
            border: none;
            box-shadow: 0 1px 4px #e11d4815;
            transition: background 0.18s, color 0.18s, box-shadow 0.18s, transform 0.15s;
        }
        .add-to-cart-btn:hover {
            background: #a31536;
            transform: scale(1.04);
        }
        .product-btn.details {
            background: #fff;
            color: #e11d48;
            border: 1.5px solid #e11d48;
        }
        .product-btn.details:hover {
            background: #e11d48;
            color: #fff;
            transform: scale(1.08);
        }
        .product-btn i, .add-to-cart-btn i {
            margin: 0 0.2rem 0 0;
            font-size: 1.15em;
        }
        .add-to-cart-btn span {
            font-weight: 800;
            font-size: 1.01em;
            margin-right: 0.2rem;
        }
        /* Tooltip يبقى فقط لزر التفاصيل */
        .product-btn.details[title]:hover:after {
            content: attr(title);
            position: absolute;
            bottom: 120%;
            left: 50%;
            transform: translateX(-50%);
            background: #23232a;
            color: #fff;
            padding: 4px 12px;
            border-radius: 0.5rem;
            font-size: 0.85rem;
            white-space: nowrap;
            box-shadow: 0 2px 8px #0002;
            opacity: 0.95;
            pointer-events: none;
            z-index: 10;
        }
        @media (max-width: 768px) {
            .product-actions {
                flex-direction: row;
                gap: 0.18rem;
                justify-content: center;
                align-items: center;
            }
            .add-to-cart-btn {
                width: auto !important;
                min-width: 80px !important;
                max-width: 100%;
                height: 32px !important;
                font-size: 0.93rem !important;
                padding: 0.5rem 0.7rem !important;
                border-radius: 0.7rem !important;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 0.4rem;
                font-weight: 800;
                background: linear-gradient(90deg, #e11d48 80%, #a31536 100%);
                color: #fff;
                border: none;
                box-shadow: 0 1px 4px #e11d4815;
                transition: background 0.18s, color 0.18s, box-shadow 0.18s, transform 0.15s;
            }
            .add-to-cart-btn:hover {
                background: #a31536;
                transform: scale(1.04);
            }
            .product-btn.details {
                width: 32px;
                height: 32px;
                min-width: 32px;
                min-height: 32px;
                max-width: 32px;
                max-height: 32px;
                font-size: 0.98rem;
            }
        }

        /* تأثير زر أضف إلى السلة عند الإضافة */
        .add-to-cart-btn.added {
            background: #22c55e !important; /* أخضر عصري */
            color: #fff !important;
            transition: background 0.18s, color 0.18s;
        }
        .add-to-cart-btn.added i {
            display: none;
        }
        .add-to-cart-btn.added .added-text {
            display: inline;
        }
        .add-to-cart-btn .added-text {
            display: none;
        }
    </style>
</head>
<body>
    <div class="desktop-section">
        <header class="main-header">
            <div class="header-container">
                <a href="index.php" class="logo">Dark<span> Store</span></a>
                <nav class="nav-links" id="mainNav">
                    <a href="index.php">الرئيسية</a>
                    <a href="products.php" class="active">المنتجات</a>
                    <a href="posts.php">المنشورات</a>
                </nav>
                <a href="admin/login.php" class="cta-btn">تسجيل الدخول</a>
            </div>
        </header>

        <section class="hero">
            <div class="container">
                <h1>استكشف <span>منتجاتنا</span> المتنوعة</h1>
                <p>تصفح أحدث المنتجات واختر ما يناسبك من بين آلاف الخيارات</p>
            </div>
        </section>

        <section class="section">
            <div class="container">
                <!-- قسم البحث والتصفية -->
                <div class="search-filter-section">
                    <form method="GET" action="products.php" class="search-container">
                        <input type="text" name="search" class="search-input" placeholder="ابحث عن منتج..." value="">
                        <button type="submit" class="search-button">
                            <i class="fas fa-search"></i> بحث
                        </button>
                    </form>
                    
                    <div class="categories-filter">
                        <a href="products.php" class="category-btn active">الكل</a>
                                            </div>
                </div>

                <h2 class="section-title">منتجات <span>متاحة</span></h2>
                <p class="section-subtitle">0 منتج متوفر </p>
                
                <div class="products-container">
                                            <div class="no-products">
                            <p>لم يتم العثور على منتجات تطابق بحثك</p>
                                                    </div>
                                    </div>
            </div>
        </section>

        <footer>
            <div class="container">
                <p>&copy; 2025 Dark Store. برمجة وتصميم ذوالفقار شلوم.</p>
            </div>
        </footer>
    </div>

    <!-- Mobile Version -->
    <div class="mobile-app">
        <div class="mobile-hero">
            <h1>استكشف <span>منتجاتنا</span> المتنوعة</h1>
            <p>تصفح أحدث المنتجات واختر ما يناسبك من بين آلاف الخيارات</p>
        </div>

        <div class="mobile-search-filter">
            <form method="GET" action="products.php" class="mobile-search-container">
                <input type="text" name="search" class="mobile-search-input" placeholder="ابحث عن منتج..." value="">
                <button type="submit" class="mobile-search-button">
                    <i class="fas fa-search"></i>
                </button>
            </form>
            
            <div class="mobile-categories-scroll">
                <a href="products.php" class="mobile-category-btn active">الكل</a>
                            </div>
        </div>

        <div class="products-container">
                            <div class="no-products">
                    <p>لم يتم العثور على منتجات تطابق بحثك</p>
                                    </div>
                    </div>

        <nav class="bottom-nav">
            <a href="index.php"><i class="fas fa-home"></i><span>الرئيسية</span></a>
            <a href="products.php"><i class="fas fa-boxes"></i><span>المنتجات</span></a>
            <a href="posts.php"><i class="fas fa-comments"></i><span>المنشورات</span></a>
            <a href="admin/login.php"><i class="fas fa-sign-in-alt"></i><span>الدخول</span></a>
        </nav>
    </div>    <!-- زر السلة العائم (Floating Cart Button) -->
    <button id="floating-cart-btn" onclick="window.location.href='cart.php'" style="position:fixed;bottom:24px;left:24px;z-index:1000;background:#e11d48;color:#fff;border:none;border-radius:50%;width:64px;height:64px;box-shadow:0 4px 24px #0004;display:flex;align-items:center;justify-content:center;font-size:2rem;transition:background 0.18s;">
        <i class="fas fa-shopping-cart"></i>
        <span id="cart-count" style="position:absolute;top:8px;left:8px;background:#fff;color:#e11d48;border-radius:50%;width:26px;height:26px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;font-weight:900;box-shadow:0 2px 8px #0002;">0</span>
    </button>
    <style>
    @media (max-width: 600px) {
        #floating-cart-btn { width:54px;height:54px;font-size:1.4rem;bottom:88px; /* رفع الزر للأعلى فقط، بدون تغيير الشريط السفلي */left:16px;top:auto !important;cursor: pointer; }
        #cart-count { width:20px;height:20px;font-size:0.95rem;top:4px;left:4px; }
        .bottom-nav {
            height: auto !important;
            min-height: 0 !important;
        }
    }
    </style>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // Active nav link (desktop)
    const navLinks = document.querySelectorAll('.nav-links a');
    function setActiveLink() {
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (
                (link.getAttribute('href') === window.location.hash && window.location.hash !== '') ||
                (link.getAttribute('href') === 'products.php' && window.location.pathname.endsWith('products.php'))
            ) {
                link.classList.add('active');
            }
        });
    }
    setActiveLink();
    window.addEventListener('hashchange', setActiveLink);
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                setTimeout(setActiveLink, 10);
            }
        });
    });

    // حل مشكلة أزرار الشريط السفلي في الهاتف (تفعيل active عند الضغط)
    const mobileNavLinks = document.querySelectorAll('.bottom-nav a');
    function setMobileActiveLink() {
        mobileNavLinks.forEach(link => link.classList.remove('active'));
        mobileNavLinks.forEach(link => {
            if (
                (link.getAttribute('href') === window.location.hash && window.location.hash !== '') ||
                (link.getAttribute('href') === 'products.php' && window.location.pathname.endsWith('products.php'))
            ) {
                link.classList.add('active');
            }
        });
    }
    setMobileActiveLink();
    window.addEventListener('hashchange', setMobileActiveLink);
    mobileNavLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                setTimeout(setMobileActiveLink, 10);
            }
        });
    });

    // حل مشكلة الصور التي لا تظهر
    document.querySelectorAll('img').forEach(img => {
        img.addEventListener('error', function() {
            this.src = 'https://via.placeholder.com/300x200?text=Image+Error';
            this.alt = 'صورة غير متاحة';
        });
    });    // تحديث عداد السلة العائم عند أي تغيير في السلة
    function updateCartCount() {
        const cart = JSON.parse(localStorage.getItem('cart') || '[]');
        let count = 0;
        cart.forEach(item => count += item.qty);
        const cartCount = document.getElementById('cart-count');
        if (cartCount) cartCount.textContent = count;
    }
    updateCartCount();
    window.addEventListener('storage', updateCartCount);
    // عند العودة للخلف (popstate) يتم تحديث العداد
    window.addEventListener('popstate', updateCartCount);

    // تحديث عداد السلة العائم عند أي تغيير في السلة
    function updateCartCount() {
        const cart = JSON.parse(localStorage.getItem('cart') || '[]');
        let count = 0;
        cart.forEach(item => count += item.qty);
        const cartCount = document.getElementById('cart-count');
        if (cartCount) cartCount.textContent = count;
    }
    // تحديث العداد عند تحميل الصفحة وأي تغيير في السلة
    document.addEventListener('DOMContentLoaded', updateCartCount);
    window.addEventListener('storage', updateCartCount);
    // تحديث العداد بعد أي إضافة/تعديل في السلة (منطقك الحالي في إضافة للسلة يجب أن يستدعي updateCartCount أيضًا)
    
    // منطق إضافة المنتج إلى السلة
    function getCart() {
        return JSON.parse(localStorage.getItem('cart') || '[]');
    }
    function setCart(cart) {
        localStorage.setItem('cart', JSON.stringify(cart));
    }
    function addToCart(product) {
        let cart = getCart();
        const idx = cart.findIndex(item => item.id == product.id);
        if (idx > -1) {
            cart[idx].qty += 1;
        } else {
            cart.push({ ...product, qty: 1 });
        }
        setCart(cart);
        updateCartCount();
    }
    // زر أضف إلى السلة (ديسكتوب + موبايل)
    document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const product = {
                id: this.getAttribute('data-id'),
                name: this.getAttribute('data-name'),
                price: parseFloat(this.getAttribute('data-price')),
                image: this.getAttribute('data-image')
            };
            addToCart(product);
            // تأثير التحويل المؤقت للزر
            const btnEl = this;
            if (!btnEl.classList.contains('added')) {
                const originalHTML = btnEl.innerHTML;
                btnEl.classList.add('added');
                btnEl.innerHTML = '<span>تمت الإضافة</span>';
                setTimeout(function() {
                    btnEl.classList.remove('added');
                    btnEl.innerHTML = originalHTML;
                }, 800);
            }
        });
    });
});
</script>
</body>
</html>